package testdata

func Foo21(i interface{}) interface{} { return nil }
