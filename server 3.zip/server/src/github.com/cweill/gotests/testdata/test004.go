package testdata

func Foo4() bool { return false }
