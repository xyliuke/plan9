package testdata

func Foo20(strs ...string) string { return "" }
