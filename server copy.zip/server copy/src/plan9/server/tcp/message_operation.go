package tcp

import (
	"common/util"
	"net"
	"server"
)

type MessageOperation interface {
	NewConnect(net.Conn) PacketOperation
}

type PacketOperation interface {
	CreateConnection(net.Conn)
	DealPacket([]byte)
	CloseConnect()
}

type BasePacketOperation struct {
	id   string
	conn net.Conn //tcp连接
	buf  []byte   //数据缓存
	len  int      //缓存数据的长度
}

func NewBasePacketOperation() *BasePacketOperation {
	op := new(BasePacketOperation)
	op.buf = make([]byte, 10240)
	op.len = 0
	op.id = util.CreateID()
	return op
}

func (self *BasePacketOperation) CreateConnection(conn net.Conn) {
	self.conn = conn
	//	log("create connection from client ip " + conn.RemoteAddr().String() + " , the connection id : " + connection.id)
}

func (self *BasePacketOperation) DealPacket(data []byte) {
	copy(self.buf[self.len:], data)
	self.len += len(data)
}
func (self BasePacketOperation) CloseConnect() {
	self.conn.Close()
}

func (self BasePacketOperation) GetDataLength(data []byte) int {
	if data[0] == '^' && len(data) >= 6 {
		a1 := int(data[2])
		a2 := int(data[3])
		a3 := int(data[4])
		a4 := int(data[5])
		return (a1 << 24) + (a2 << 16) + (a3 << 8) + a4
	}
	return -1
}

//对网络协议的解析类
func (self BasePacketOperation) GetTypeValue(data []byte) (*server.NetworkError, byte) {
	if len(data) >= 6 && data[0] == '^' {
		//		头部有6个字节
		return nil, data[1]
	}
	return server.CreateNetworkError(server.NETWORK_ERROR_ILLEGAL_PROTOCOL), '^'
}

//判断是否为ping包类型
func (self BasePacketOperation) IsPingType(tp byte) bool {
	if tp == 0x02 {
		return true
	}
	return false
}

func (self BasePacketOperation) writeString(data string) {
	len := len(data)
	header := []byte{'^', 0x01, byte((len & 0xFF000000) >> 24), byte((len & 0x00FF0000) >> 16), byte((len & 0x0000FF00) >> 8), byte(len & 0x000000FF)}
	tmp := make([]byte, len+6)
	copy(tmp, header)
	copy(tmp[6:], []byte(data))
	self.conn.Write(tmp)
}
