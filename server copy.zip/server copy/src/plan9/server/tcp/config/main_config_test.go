package config

import (

	"testing"
	"fmt"
	"container/list"
)


func TestCreateMainConfig(t *testing.T)  {
	NewMainConfigServer()
	list := list.New()
	list.PushBack(1);
	list.PushFront(2)
	list.PushBack(3)
	list.PushBack("hello")
	list.PushBack("world")
	for e := list.Front(); e != nil; e = e.Next() {
		fmt.Print(e.Value, " ")
		if e.Value == "hello" {
			fmt.Println(" == ", e.Value)
//			list.Remove(e)
		}
	}
	fmt.Println("\n", list.Len())


	m := make(map[int]string, 10)
	m[1] = "hhhh"
	delete(m, 1)
	fmt.Println("map size : ", len(m))
}

