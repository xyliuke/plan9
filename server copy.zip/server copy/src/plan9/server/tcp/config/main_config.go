//主配置服务器,监控所有其他配置服务器的运行情况
package config
import (
	"net"
	"fmt"
)



//主配置服务器类
type MainConfigServer struct  {
	//服务器之间依赖关系,key是当前服务器,value为需要连接当前服务器的服务器,比如key为路由服务器,value为连接服务器,连接服务器需要连接路由服务器
	//不存在一种服务器被多种服务器连接,如数据库服务器不能即被业务服务器连接,同时也被路由服务器连接
	dependRule map[int]int
	servers	map[int]*ServerConfigUnit//所有其他服务器配置集合
}

func NewMainConfigServer() *MainConfigServer {
	main := new(MainConfigServer)
	main.initDependentRule()
	main.servers = make(map[int]*ServerConfigUnit, 10)
	return main
}

//初始化服务器依赖关系规则
func (self *MainConfigServer)initDependentRule()  {
	if self.dependRule == nil {
		self.dependRule = make(map[int]int, 10)
	}
	self.dependRule[SERVER_TYPE_DATABASE] = SERVER_TYPE_SESSION
	self.dependRule[SERVER_TYPE_OTHER] = SERVER_TYPE_SESSION
	self.dependRule[SERVER_TYPE_SESSION] = SERVER_TYPE_ROUTE
	self.dependRule[SERVER_TYPE_ROUTE] = SERVER_TYPE_CONNECT
}

func (self *MainConfigServer) addServerConfigUnit()  {

}

//启动主配置服务器的监听
func (self *MainConfigServer) Listen()  {
	listen, err := net.Listen("tcp", ":9000");
	if err != nil {
		fmt.Println(err)
		return
	}
	conn, err_conn := listen.Accept()
	if err_conn != nil {
		fmt.Println(err_conn)
		return
	}

}





func (self *MainConfigServer) dispatch()  {
	
}





