package config


const (
	SERVER_TYPE_CONNECT  = iota  //连接服务器
	SERVER_TYPE_ROUTE  = iota  //路由服务器
	SERVER_TYPE_SESSION = iota //业务服务器
	SERVER_TYPE_DATABASE = iota //数据库服务器
	SERVER_TYPE_OTHER = iota //其它服务器
)

//微服务器的相关信息,包括ip,端口等
type MicroServerInfo struct  {
	ip string
	port int
	enable bool	//是否可用
}

//服务器配置单元,保存一个配置服务器所有的相关信息
type ServerConfigUnit struct  {
	id string	//配置服务器的id
	serverType int	//配置服务器类型
	servers []MicroServerInfo	//该配置服务器下所管理的微服务器信息

}
