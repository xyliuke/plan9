package connect

import (
	"net"
	"server/tcp"
)

type ConnectServerOperation struct {
	basePacket *tcp.BasePacketOperation
}

func NewConnectServerOperation() *ConnectServerOperation {
	conn := new(ConnectServerOperation)
	conn.basePacket = tcp.NewBasePacketOperation()
	return conn
}

func (self *ConnectServerOperation) CreateConnection(conn net.Conn) {
	self.basePacket.CreateConnection(conn)
}

func (self *ConnectServerOperation) DealPacket(data []byte) {
	self.basePacket.DealPacket(data)
	//自己服务器的处理方法
}
func (self ConnectServerOperation) CloseConnect() {
	self.basePacket.CloseConnect()
}
