package connect

import (
	"net"
	"server/tcp"
)

type ConnectServer struct {
	baseServer *tcp.TcpCommonServer
}

func NewConnectServer() *ConnectServer {
	conn := new(ConnectServer)
	msgOp := new(ConnectMessageServer)
	conn.baseServer = tcp.NewTcpServer(8081, msgOp)
	return conn
}

func (self *ConnectServer) Listen() {
	self.baseServer.Listen()
}

type ConnectMessageServer struct {
}

func (self *ConnectMessageServer) NewConnect(conn net.Conn) tcp.PacketOperation {
	csop := NewConnectServerOperation()
	csop.CreateConnection(conn)
	return csop
}

//func (self ConnectServer) ()  {
//
//}
