package tcp

import (
	"net"
	"strconv"
	"fmt"
)

type TcpCommonServer struct {
	port int
	mop  MessageOperation
}

func NewTcpServer(port int, mop MessageOperation) *TcpCommonServer {
	tcp := new(TcpCommonServer)
	tcp.port = port
	tcp.mop = mop
	return tcp
}

func (server *TcpCommonServer) Listen() {
	ip := ":" + strconv.Itoa(server.port)
	listen, err := net.Listen("tcp", ip)
	if err != nil {
		//监听错误
		fmt.Println(err.Error())
		return
	}
	for {
		conn, err1 := listen.Accept()
		if err1 == nil {
			go server.handleConnection(conn)
		}
	}
}

func (server TcpCommonServer) handleConnection(conn net.Conn) {
	go server.handleRead(conn)
}

func (server TcpCommonServer) handleRead(conn net.Conn) {
	connection := server.mop.NewConnect(conn)
	defer connection.CloseConnect()

	data := make([]byte, 2048)
	for {
		len, err := conn.Read(data)
		if err == nil {
			read_data := make([]byte, len)
			copy(read_data, data)
			connection.DealPacket(read_data)
		} else {
			break
		}
	}
}
