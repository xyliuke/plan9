package tcp


type TcpCommonClient struct  {
	ip string
	port int
}

func NewCommonClient() *TcpCommonClient  {
	cl := new(TcpCommonClient)
	return cl;
}

//连接服务器
func (self *TcpCommonClient) Connect(ip string, port int)  {
	
}

//向服务器发送数据
func (self *TcpCommonClient) Write(data []byte)  {

}
//关闭连接
func (self *TcpCommonClient) Close()  {

}
