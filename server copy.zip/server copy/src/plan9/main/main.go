package main

import (
	"server/tcp/connect"
	//	"io"
	//	"log"
	//	"net"
	//	"os"
	// "net/http"
	//	 "runtime"
)

func main() {
	cs := connect.NewConnectServer()
	cs.Listen()
}
