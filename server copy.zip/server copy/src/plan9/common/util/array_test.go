package util

import (
	"testing"
	"fmt"
)



func Test_Array(t *testing.T)  {
	arr := NewArray()
	arr.Push(1)
	arr.Push(2)
	arr.Push(3)
	arr.Push(4)
	arr.Push(5)
	arr.Push(6)
	for i := 0; i < arr.Size(); i ++ {
		fmt.Print(arr.Get(i), ",")
	}
	fmt.Println()
	arr.Set(10, 2)
	for i := 0; i < arr.Size(); i ++ {
		fmt.Print(arr.Get(i), ",")
	}
	fmt.Println()

//	arr.ToString()

//	s6 := arr.Pop()
//	fmt.Println(s6)
//	arr.ToString()

//	arr.Push(9)
//	for i := 0; i < arr.Size(); i ++ {
//		fmt.Println(arr.Get(i))
//	}
}