package util
import "container/list"

//链表结构的List,封装Go中的list
type List struct  {
	list.List
}

func NewList() *List{
	l := new(List)
	return l
}

//func (self *List) Remove(e *list.Element) interface{}  {
//	ret := self.List.Remove(e)
//	if e.Prev() != nil && e.Next() != nil {
////		self.List.InsertAfter(e.Next(), e.Prev())
////		self.List.MoveAfter(e.Next(), e.Prev())
//	}
//
////	e.Prev().Next() = e.Next()
//	return ret
//}
