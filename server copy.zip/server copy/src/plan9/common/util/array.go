package util


//数组类,封装了Go的切片,可以动态添加删除元素.因为使用数组作为数据结构,
//方便查找,不方便从中间添加和删除
type Array struct  {
	value []interface{}
	len int
}

//创建一个默认的数组
func NewArray() *Array  {
	return NewArrayCapacity(20)
}
//创建一个指定容量的数组
func NewArrayCapacity(cap int) *Array  {
	arr := new(Array)
	arr.len = 0
	arr.value = make([]interface{}, 0, cap)
	return arr
}
//向数组中添加一个元素
func (self *Array) Push(val interface{})  {
	if self.len < len(self.value) {
		self.value[self.len] = val
	} else {
		self.value = append(self.value, val)
	}
	self.len ++
}
//删除最后一个添加的元素
func (self *Array) Pop() interface{}  {
	if self.len == 0 {
		return nil
	}
	val := self.value[self.len - 1]
	self.len --
	return val
}
//获取第index个元素
func (self *Array) Get(index int) interface{}  {
	if self.len > index && index >= 0 {
		return self.value[index]
	}
	return nil
}
//设置第index个元素的值,index值必须在0和Size()之间
func (self *Array) Set(val interface{}, index int)  {
	if index >= 0 && index <self.Size() {
		self.value[index] = val
	}
}
//返回数组中元素的个数
func (self* Array) Size() int  {
	return self.len
}

func (self* Array) String() string {
	str := "["
//	for i := 0; i < self.len; i ++ {
//		fmt.Print(self.value[i].String())
//		str += string(self.value[i])
//		if i != (self.len - 1) {
//			str += ","
//			fmt.Print(",")
//		}
//	}
	str += "]"
//	fmt.Println()
	return str
}