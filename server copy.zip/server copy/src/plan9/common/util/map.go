package util


type Map struct {
	value map[interface{}]interface{}
}
