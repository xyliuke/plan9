package util
import (
	"testing"
	"fmt"
)


func Test_List(t *testing.T)  {
	fmt.Println(" list test........ begin")
	l := NewList()
	l.PushBack(1)
	l.PushBack(2)
	l.PushBack(3)
	for v := l.Front(); v != nil; v = v.Next() {
		if v.Value == 2 {
			_ = l.Remove(v)
			break
		}
	}
	for v := l.Front(); v != nil; v = v.Next() {
		fmt.Println(v.Value)
	}
	fmt.Println(" list test........ end")
}
