package util
import (
	"testing"
	"fmt"
)

func Test_map(t *testing.T)  {
	fmt.Println("begin map test")
	m := make(map[int]string, 1)
	m[1] = "a"
	m[2] = "b"
	fmt.Println(len(m))
	fmt.Println("end map test")
}
