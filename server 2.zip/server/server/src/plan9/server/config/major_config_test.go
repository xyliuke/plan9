package config

import "testing"

func Test_MajorConfigServer(t *testing.T)  {
	NewMajorConfigServer(0, 0, 0, 8081)
}