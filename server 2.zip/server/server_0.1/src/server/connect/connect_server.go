package connect

import (
	"server/base"
	"net"
)

type ConnectServer struct  {
	*base.BaseProtocolTcpServer
}

func NewConnectServer(port int) *ConnectServer {
	c := new(ConnectServer)
	c.BaseProtocolTcpServer = base.NewBaseProtocolTcpServer(port, c)
	return c
}

func (this *ConnectServer) Connected(conn net.Conn)  {
	
}

func (this *ConnectServer) Disconnected(net.Conn) {

}

func (this *ConnectServer) ReadData(net.Conn, []byte) {

}

func (this *ConnectServer) WriteData(int, []byte) {

}
