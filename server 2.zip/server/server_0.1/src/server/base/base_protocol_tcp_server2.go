package base

import (
	"common/net/tcp"
	"net"
)

type BaseProtocolTcpServer2 struct {
	*tcp.TcpServer2
}

func NewBaseProtocolTcpServer2(port int) *BaseProtocolTcpServer2 {
	b := new(BaseProtocolTcpServer2)

	b.TcpServer2 = tcp.NewTcpServer2(port)
	b.SetHandler(b)

	return b
}

func (this *BaseProtocolTcpServer2) ClientConnectedToServer(net.Conn) {

}

func (this *BaseProtocolTcpServer2) ClientDisconnectedToServer(net.Conn) {

}

func (this *BaseProtocolTcpServer2) ReadClientData(net.Conn, []byte) {

}