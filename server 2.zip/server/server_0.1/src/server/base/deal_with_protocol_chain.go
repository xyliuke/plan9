package base

type DealWithProtocolChainInterface interface {
	DealWithProtocol(id int, ver byte, serverType byte, dataType byte, oriDataLen int, oriData []byte, finalDataLen int, finalData []byte);
	Next() DealWithProtocolChainInterface
}

