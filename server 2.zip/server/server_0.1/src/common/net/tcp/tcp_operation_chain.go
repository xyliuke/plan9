package tcp

import "net"

type ConnectHandler interface  {
	ConnectHandler(net.Conn)
	NextConnectHandler() ConnectHandler
}

type DisconnectedHandler interface  {
	Disconnected(net.Conn)
	NextDisconnectedHandler() DisconnectedHandler
}

type ReadDataHandler interface {
	ReadClientDataHandler(net.Conn, []byte)
	NextReadDataHandler() ReadDataHandler
}

type WriteDataHandler interface  {
	WriteData2ClientHandler(net.Conn, []byte)
	NextWriteDataHandler() WriteDataHandler
}


