package tcp

import (
	"net"
	"strconv"
	"common/log"
)

type TcpServerHandler2 interface {
	ClientConnectedToServer(net.Conn)
	ClientDisconnectedToServer(net.Conn)
	ReadClientData(net.Conn, []byte)
}

type TcpServer2 struct {
	port int
	delegate TcpServerHandler2
}

func NewTcpServer2(port int) *TcpServer2 {
	s := new(TcpServer2)
	s.port = port
	return s
}

func (this* TcpServer2) SetHandler(handler TcpServerHandler2)  {
	this.delegate = handler
}

func (this *TcpServer2) Listen() {
	ip := ":" + strconv.Itoa(this.port)
	listen, err := net.Listen("tcp", ip)
	if err == nil {
		log.I_NET("tcp server", ip, "listening")
		for true {
			conn, err_conn := listen.Accept()
			if err_conn == nil {
				go this.doConnect(conn)
			} else {
				log.E_NET("accept tcp error, the reason : ", err)
			}
		}
	} else {
		log.E_NET("listen tcp error, the reason : ", err)
	}
}

func (this *TcpServer2) doConnect(conn net.Conn)  {
	log.I_NET(conn.RemoteAddr(), " connect to server success")
	if this.delegate != nil {
		this.delegate.ClientConnectedToServer(conn)
	}
	data := make([]byte, 2048)
	defer conn.Close()
	for {
		len, err := conn.Read(data)
		if err == nil {
			read_data := make([]byte, len)
			copy(read_data, data)
			log.D_NET(conn.LocalAddr(), "read from client", conn.RemoteAddr(), "data :", read_data)
			if this.delegate != nil {
				this.delegate.ReadClientData(conn, read_data)
			}
		} else {
			log.E_NET("read from client", conn.RemoteAddr(),"error, reason :", err)
			break
		}
	}
	log.I_NET("client ", conn.RemoteAddr(), " close")
	if this.delegate != nil {
		this.delegate.ClientDisconnectedToServer(conn)
	}
}

func (this* TcpServer2) Write(conn net.Conn, data []byte)  {
	if conn != nil {
		conn.Write(data)
	}
}