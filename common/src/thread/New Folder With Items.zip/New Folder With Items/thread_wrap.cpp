//
// Created by liuke on 15/11/1.
//

#include "thread_wrap.h"
#include "thread_dispatch.h"
#include <thread/thread_define.h>
#include <uv.h>
#include <log/log_wrap.h>
#include <iostream>

namespace plan9{

    static uv_loop_t* loop = nullptr;
    static uv_thread_t *thread = nullptr;

    struct function_wrap {
        std::function<void(void)> function;
    };

    static void queue_callback(uv_work_t* work) {
        log_wrap::io().d("queue callback begin");
        if (work->data != nullptr) {
            function_wrap* func = (function_wrap*)(work->data);
            func->function();
            delete(func);
            delete(work);
        }
    }

    static void run(void* args) {
        if (loop == nullptr) {
            loop = uv_default_loop();
            if (args != nullptr) {
                function_wrap* f = (function_wrap*)args;
                f->function();
                delete(f);
            }
            uv_run(loop, UV_RUN_DEFAULT);
        } else {
            if (args != nullptr) {
                function_wrap* f = (function_wrap*)args;
                f->function();
                delete(f);
            }
        }
    }

    static void close_async_callback(uv_handle_t* handle) {
        delete(handle);
        handle = nullptr;
    }

    static void async_callback(uv_async_t* async) {
        std::cout << "async_callback " << std::endl;
        if (async->data != nullptr) {
            auto *f = (function_wrap*)async->data;
            f->function();
            delete(f);
        }
//        uv_close((uv_handle_t*)async, close_async_callback);
    }

    static bool background = false;

    void thread_wrap::init(std::function<void(void)> callback) {
#ifdef THREAD_ENABLE
        if (loop == nullptr) {
            thread = new uv_thread_t;
            function_wrap* f = new function_wrap;
            f->function = callback;
            uv_thread_create(thread, run, (void*)f);
        } else {
            callback();
        }
#else
        callback();
#endif
    }

    void thread_wrap::post_concurrent_background(std::function<void(void)> func) {
#ifdef THREAD_ENABLE
    post(func);
#else
        func();
#endif
    }

    void thread_wrap::post_serial_background(std::function<void(void)> function) {
#ifdef THREAD_ENABLE
//        if (!background) {
//            thread_dispatch::create(1);
//            background = true;
//        }
//        thread_dispatch::post(1, function);

        if (loop == nullptr) {
            thread_wrap::init([=](){
                auto async = new uv_async_t;
                auto f = new function_wrap;
                f->function = function;
                async->data = (void*)f;
                uv_async_init(loop, async, async_callback);
                uv_async_send(async);
            });
        } else {
            auto async = new uv_async_t;
            auto f = new function_wrap;
            f->function = function;
            async->data = (void*)f;
            uv_async_init(loop, async, async_callback);
            uv_async_send(async);
        }
#else
        function();
#endif
    }

    int thread_wrap::post_background(std::function<void(void)> function, long milliseconds, bool repeat) {
        if (!background) {
            thread_dispatch::create(1);
            background = true;
        }
        return thread_dispatch::post(1, function, milliseconds, repeat);
    }

    void thread_wrap::cancel_background_function(int id) {
        thread_dispatch::cancel(1, id);
    }

    void thread_wrap::post_network(std::function<void(void)> func) {
        static bool created = false;
        if (!created) {
            thread_dispatch::create(2);
        }

        thread_dispatch::post(2, func);
    }

    void thread_wrap::post_io(std::function<void(void)> func) {
        static bool created = false;
        if (!created) {
            thread_dispatch::create(3);
        }

        thread_dispatch::post(3, func);
    }

    void thread_wrap::stop() {
        thread_dispatch::stop();
    }



    void thread_wrap::post(std::function<void(void)> func) {
        if (loop != nullptr) {
            uv_work_t* work = new uv_work_t;
            function_wrap* f = new function_wrap;
            f->function = func;
            work->data = (void*)f;
            uv_queue_work(loop, work, queue_callback, NULL);
        } else {
            func();
        }
    }
}