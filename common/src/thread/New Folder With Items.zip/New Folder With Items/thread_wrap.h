//
// Created by liuke on 15/11/1.
//

#ifndef COMMON_THREAD_WRAP_H
#define COMMON_THREAD_WRAP_H


#include <functional>

namespace plan9 {

    class thread_wrap {
    public:
        /**
         * 向并行队列post一个任务
         * @param func 任务
         */
        static void post_concurrent_background(std::function<void(void)> func);
        /**
         * 向串行队列post一个任务
         * @param function 任务
         */
//        static void post_serial_background(std::function<void(void)> function);

        static int post_background(std::function<void(void)> function, long milliseconds, bool repeat);

        static void cancel_background_function(int id);

        /**
         * 向网络线程post一个方法
         */
        static void post_network(std::function<void(void)> func);

        /**
         * 向IO线程post一个方法
         */
        static void post_io(std::function<void(void)> func);

        /**
         * 停止上面所有线程
         */
        static void stop();

        static void post(std::function<void(void)> func);
    };
}

#endif //COMMON_THREAD_WRAP_H
